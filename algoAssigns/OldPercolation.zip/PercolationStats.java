import edu.princeton.cs.algs4.StdRandom;

/**
 *
 * @author ghaith
 */
public final class PercolationStats {

    private static final double C = 1.96;
    private final double[] p;
    private final int t;
    private final double x, s, ch, cl;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n < 0 || trials < 0) {
            throw (new IllegalArgumentException());
        }
        t = trials;
        p = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation perc = new Percolation(n);
            while (true) {
                perc.open(StdRandom.uniform(n) + 1, StdRandom.uniform(n) + 1);
                if (perc.percolates()) {
                    break;
                }
            }
            p[i] = (double) perc.numberOfOpenSites() / (double) (n * n);
        }
        x = mean();
        s = stddev();
        ch = confidenceHi();
        cl = confidenceLo();
    }

    // sample mean of percolation threshold
    public double mean() {
        double sum = 0;
        for (int i = 0; i < t; i++) {
            sum += p[i];
        }
        return sum / t;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        double sum = 0;
        for (int i = 0; i < t; i++) {
            sum += (p[i] - x) * (p[i] - x);
        }
        return Math.sqrt(sum / (t - 1));
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return x - (C * s) / Math.sqrt(t);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return x + (C * s) / Math.sqrt(t);
    }

    // test client (see below)
    public static void main(String[] args) {
        PercolationStats PS = new PercolationStats(Integer.parseInt(args[1]), Integer.parseInt(args[0]));
        System.out.println("mean                    = " + PS.x);
        System.out.println("stddev                  = " + PS.s);
        System.out.println("95% confidence interval = [" + PS.cl + ", " + PS.ch + "]");

    }

}

